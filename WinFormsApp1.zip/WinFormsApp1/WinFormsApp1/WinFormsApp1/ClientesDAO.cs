﻿using System.Data;

public class ClientesDAO
{
    private ConexionDB conexion;

    public ClientesDAO()
    {
        conexion = new ConexionDB();
    }



    public DataTable BuscarClientes(string texto)
    {
        var parametros = new Dictionary<string, object> { { "@p_texto", texto } }; 
        return conexion.EjecutarConsulta("buscar_clientes", parametros);
    }

    // Método para insertar un cliente
    public void InsertarCliente(string nombre, string apellido, string direccion)
    {
        var parametros = new Dictionary<string, object>
        {
            { "@p_nombre", nombre },
            { "@p_apellido", apellido },
            { "@p_direccion", direccion }
        };

        conexion.EjecutarComando("insertar_cliente", parametros);
    }

    // Método para obtener todos los clientes
    public DataTable ObtenerClientes()
    {
        var parametros = new Dictionary<string, object>();
        return conexion.EjecutarConsulta("obtener_clientes", parametros);
    }

    // Método para actualizar un cliente
    public void ActualizarCliente(int idCliente, string nombre, string apellido, string direccion)
    {
        var parametros = new Dictionary<string, object>
        {
            { "@p_idCliente", idCliente },
            { "@p_nombre", nombre },
            { "@p_apellido", apellido },
            { "@p_direccion", direccion }
        };

        conexion.EjecutarComando("actualizar_cliente", parametros);
    }

    // Método para eliminar un cliente
    public void EliminarCliente(int idCliente)
    {
        var parametros = new Dictionary<string, object>
        {
            { "@p_idCliente", idCliente }
        };

        conexion.EjecutarComando("eliminar_cliente", parametros);
    }
}
