﻿using System;
using System.Data;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

public class ConexionDB : IDisposable
{
    private MySqlConnection cn;

    public ConexionDB()
    {
        cn = new MySqlConnection("server=localhost; database=tiendau4; user=root; pwd=root");
        cn.Open();
        Console.WriteLine("Conectado " + cn.State);
    }


    // Método para ejecutar comandos (UPDATE, DELETE) con procedimientos almacenados
    public void EjecutarComando(string query, Dictionary<string, object> parametros)
    {
        try
        {
            using (MySqlCommand cmd = new MySqlCommand(query, cn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                foreach (var param in parametros)
                {
                    cmd.Parameters.AddWithValue(param.Key, param.Value);
                }
                cmd.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al ejecutar el comando: " + ex.Message);
        }
    }



    public DataTable EjecutarConsulta(string query, Dictionary<string, object> parametros)
    {
        DataTable dt = new DataTable();
        try
        {
            using (MySqlCommand cmd = new MySqlCommand(query, cn))
            {
                cmd.CommandType = CommandType.StoredProcedure; // Asegúrate de que el comando sea un procedimiento almacenado
                foreach (var param in parametros)
                {
                    cmd.Parameters.AddWithValue(param.Key, param.Value);
                }

                using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                {
                    da.Fill(dt);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al ejecutar la consulta: " + ex.Message);
        }
        return dt;
    }



    public DataTable EjecutarConsulta1(string query, Dictionary<string, object> parametros)
    {
        DataTable dt = new DataTable();
        try
        {
            using (MySqlCommand cmd = new MySqlCommand(query, cn))
            {
                foreach (var param in parametros)
                {
                    cmd.Parameters.AddWithValue(param.Key, param.Value);
                }

                using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                {
                    da.Fill(dt);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error al ejecutar la consulta: " + ex.Message);
        }
        return dt;
    }
  
    public void Dispose()
    {
        if (cn != null)
        {
            cn.Close();
            cn.Dispose();
        }
    }
}
