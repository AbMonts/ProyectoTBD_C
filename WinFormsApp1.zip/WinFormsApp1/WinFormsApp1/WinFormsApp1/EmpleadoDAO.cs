﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    using System.Data;
    using System.Collections.Generic;

    public class EmpleadoDAO
    {
        private ConexionDB conexion;

        public EmpleadoDAO()
        {
            conexion = new ConexionDB();
        }


        public DataTable BuscarEmpleados(string texto)
        {
            var parametros = new Dictionary<string, object> { { "@p_texto", texto } }; 
            return conexion.EjecutarConsulta("buscar_empleados", parametros);


        }
        // Método para obtener todos los empleados
        public DataTable ObtenerEmpleados()
        {
            var parametros = new Dictionary<string, object>();
            return conexion.EjecutarConsulta("obtener_empleados", parametros);
        }

        // Método para insertar un empleado
        public void InsertarEmpleado(string nombre, string apellido, string usuario, string pass, float salario, string foto)
        {
            var parametros = new Dictionary<string, object> 
            { 
                { "@p_nombre", nombre },
                { "@p_apellido", apellido }, 
                { "@p_usuario", usuario }, 
                { "@p_pass", pass }, 
                { "@p_salario", salario }, 
                { "@p_foto", foto }
            }; 
            conexion.EjecutarComando("insertar_empleado", parametros);
        }


        public void ActualizarEmpleado(int idEmpleado, string nombre, string apellido, string usuario, string pass, float salario, string foto)
        {
            var parametros = new Dictionary<string, object>
    {
        { "@p_idEmpleado", idEmpleado },
        { "@p_nombre", nombre },
        { "@p_apellido", apellido },
        { "@p_usuario", usuario },
        { "@p_pass", pass },
        { "@p_salario", salario },
        { "@p_foto", foto }
    };

            conexion.EjecutarComando("actualizar_empleado", parametros);
        }


        // Método para eliminar un empleado
        public void EliminarEmpleado(int idEmpleado)
        {
            var parametros = new Dictionary<string, object>
        {
            { "@p_idEmpleado", idEmpleado }
        };

            conexion.EjecutarComando("eliminar_empleado", parametros);
        }
    }

}
