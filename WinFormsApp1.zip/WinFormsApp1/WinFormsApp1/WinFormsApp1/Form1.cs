using System;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Security.Cryptography.Xml;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Mysqlx.Cursor;
using static Mysqlx.Expect.Open.Types.Condition.Types;

namespace WinFormsApp1
{
    public partial class Form1 : Form

    {

        DAOBase x;
        List<Producto> lista = new List<Producto>();
        decimal total = 0;
        public Form1()
        {
            InitializeComponent();
            //this.generarReporte.Click += generarReporte_Click;


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            x = new DAOBase();
            if (x.login(textBox1.Text, textBox2.Text) == true)
            {
                loginP.Enabled = false;
                perfilP.Enabled = true;
                busquedaP.Enabled = true;

                productoP.Enabled = true;
                perfilP.Visible = true;
                dataGridView2.Visible = true;
                dataGridView2.Enabled = true;
                x.actualizarVentas(dataGridView2);
                rellenarDatos();
                this.Size = new Size(1019, 738);
                label10.Visible = true;


            }
            else
            {
                label5.Visible = true;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void rellenarDatos()
        {
            nombre_apellidos.Text = x.user.nombre + " " + x.user.apellido;
            pictureBox1.ImageLocation = x.user.imagen;
            usuario.Text = x.user.usuario;
            idEmp.Text = "ID:" + x.user.idempleado;
            sueldo.Text = "SUELDO: $" + x.user.salario + " SEMANALES.";
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click_2(object sender, EventArgs e)
        {

        }

        private void cobro_Click(object sender, EventArgs e)
        {
            if (lista.Count > 0)
            {
                x.vender(lista, textBox4.Text, total);
                actualizarTotal();
                x.actualizarTabla(dataGridView1);
                x.actualizarVentas(dataGridView2);
                lista.Clear();
                actualizarTotal();
            }
            else
            {
                MessageBox.Show("LA VENTA ESTA VACIA");
            }


        }

        private void perfilP_MouseEnter(object sender, EventArgs e)
        {
            perfilP.BackColor = SystemColors.GrayText;
        }

        private void perfilP_MouseLeave(object sender, EventArgs e)
        {
            perfilP.BackColor = SystemColors.Window;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void perfilP_MouseClick(object sender, MouseEventArgs e)
        {
            if (perfilP.Height == 79)
            {
                perfilP.Size = new Size(240, 159);
            }
            else
            {
                perfilP.Size = new Size(240, 79);
            }
        }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            // Realizar la b�squeda cuando el texto cambie
            string textoBusqueda = textBox3.Text;
            buscar(textoBusqueda);
        }

        private void dataGridView2_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void busquedaP_Paint(object sender, PaintEventArgs e)
        {

        }


        private void buscar(string texto)
        {
            // Llamar al m�todo buscar desde la instancia de DAOBase
            x.buscar(texto, busquedaa);
        }
        public void rellenarProducto()
        {
            codigoPr.Text = "Codigo: " + x.productoS.Codigo;
            nombrePr.Text = "Nombre: " + x.productoS.Nombre;
            cantPr.Text = "Cantidad: " + x.productoS.Cantidad;
            precioPr.Text = "Precio: $" + x.productoS.Precio;
            productoImagen.ImageLocation = x.productoS.Imagen;
        }

        private void busquedaa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string codigo = busquedaa.Rows[e.RowIndex].Cells["idProducto"].Value.ToString();
                x.productoSeleccionado(codigo);
                rellenarProducto();
            }

        }
        private void agregarB_Click(object sender, EventArgs e)
        {
            bool bandera = false;
            x.productoS.cant = int.Parse(numericUpDown1.Text);
            if (x.productoS.IdProducto != 0)
            {
                x.ventaBack(x.enviarP());
                for (int i = 0; i < lista.Count; i++)
                {
                    if (lista[i].IdProducto == x.productoS.IdProducto)
                    {
                        lista[i].cant = x.productoS.cant;
                        bandera = true;
                    }

                }
                if (bandera == false)
                {
                    lista.Add(x.enviarP());
                }
            }
            actualizarTotal();
            x.actualizarTabla(dataGridView1);

        }
        private void actualizarTotal()
        {
            total = 0;
            for (int i = 0; i < lista.Count; i++)
            {
                total = total + (lista[i].Precio * lista[i].cant);
            }
            totalT.Text = "$" + total;
            iva.Text = "$" + (total / 100) * 16;
            subtotal.Text = "$" + (total / 100) * 84;

        }

        private void eliminarP_Click(object sender, EventArgs e)
        {
            bool bandera = false;
            int o = 0;
            for (int i = 0; i < lista.Count; i++)
            {
                if (lista[i].IdProducto == x.productoS.IdProducto)
                {
                    bandera = true;
                    o = i;
                }

            }
            if (bandera == true)
            {
                lista.Remove(lista[o]);
                x.eliminarPa(x.productoS.IdProducto);
                actualizarTotal();
                x.actualizarTabla(dataGridView1);
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (int.Parse(numericUpDown1.Text) > x.productoS.Cantidad)
            {
                MessageBox.Show("NO HAY EN INVENTARIO");
                numericUpDown1.Value = x.productoS.Cantidad;
            }

        }



        private void cancelar_Click(object sender, EventArgs e)
        {
            x.cancelarTransaccion();
            x.actualizarTabla(dataGridView1);
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }


        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.A)
            {
                agregarB_Click(sender, e);
            }
            else if (e.KeyCode == Keys.F10)
            {
                eliminarP_Click(sender, e);
            }
            else if (e.KeyCode == Keys.F11)
            {
                cancelar_Click(sender, e);
            }
            else if (e.KeyCode == Keys.F12) ;
            {
                cobro_Click(sender, e);

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (loginP.Enabled == false)
            {
                x.cancelarTransaccion();
                x.CerrarDAO();
            }


        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string busqueda = "";
            if (textBox5.Text == "")
            {
                busqueda = "0";
            }
            else
            {
                busqueda = textBox5.Text;

            }
            x.buscarCliente(busqueda, clienteGrid);



        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void agregarCliente_Click(object sender, EventArgs e)
        {
          
        }

        private void seleccionarCliente_Click(object sender, EventArgs e)
        {
            infoVenta.Text = x.infoVent();
        }

        private void clienteGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string codigo = clienteGrid.Rows[e.RowIndex].Cells["idCliente"].Value.ToString();
                x.seleccionarUsuario(codigo);
                infoVenta.Text = x.infoVent();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            x.mostrador();
            infoVenta.Text = x.infoVent();
        }

        private void label21_Click(object sender, EventArgs e)
        {

        }



        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void busquedaa_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string codigo = busquedaa.Rows[e.RowIndex].Cells["idProducto"].Value.ToString();
                x.productoSeleccionado(codigo);
                rellenarProducto();
            }
        }

        private void dataGridVie1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            string codigo = dataGridView1.Rows[e.RowIndex].Cells["idProducto"].Value.ToString();
            x.productoSeleccionado(codigo);
            rellenarProducto();
        }

        private void dataGridView1_MouseEnter(object sender, EventArgs e)
        {

        }

        private void busquedaa_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void otraVent_Click(object sender, EventArgs e)
        {
            containers c = new containers();
            c.ShowDialog();
            
        }
    }
}
