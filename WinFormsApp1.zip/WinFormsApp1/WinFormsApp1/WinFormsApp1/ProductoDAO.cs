﻿using System;
using System.Data;
using System.Collections.Generic;

public class ProductoDAO
{
    private ConexionDB conexion;

    public ProductoDAO()
    {
        conexion = new ConexionDB();
    }

    public DataTable BuscarProductos(string texto) { var parametros = new Dictionary<string, object> { 
        { "@p_texto", texto } }; 
        return conexion.EjecutarConsulta("buscar_productos", parametros); 
    }

    public void InsertarProducto(string nombre, string codigo, decimal precio, string descripcion, int cantidad, int idMarca, string imagen)
    {
        var parametros = new Dictionary<string, object>
        {
            { "@p_nombre", nombre },
            { "@p_codigo", codigo },
            { "@p_precio", precio },
            { "@p_descripcion", descripcion },
            { "@p_cantidad", cantidad },
            { "@p_idMarca", idMarca },
            { "@p_imagen", imagen }
        };

        conexion.EjecutarComando("insertar_producto", parametros);
    }

    public DataTable ObtenerProductos()
    {
        var parametros = new Dictionary<string, object>();
        return conexion.EjecutarConsulta("obtener_productos", parametros);
    }


    public void ActualizarProducto(int idProducto, string nombre, string codigo, decimal precio, string descripcion, int cantidad, int idMarca, string imagen)
    {
        var parametros = new Dictionary<string, object>
        {
            { "@p_idProducto", idProducto },
            { "@p_nombre", nombre },
            { "@p_codigo", codigo },
            { "@p_precio", precio },
            { "@p_descripcion", descripcion },
            { "@p_cantidad", cantidad },
            { "@p_idMarca", idMarca },
            { "@p_imagen", imagen }
        };

        conexion.EjecutarComando("actualizar_producto", parametros);
    }

    public void EliminarProducto(int idProducto)
    {
        var parametros = new Dictionary<string, object>
        {
            { "@p_idProducto", idProducto }
        };

        conexion.EjecutarComando("eliminar_producto", parametros);
    }
}
