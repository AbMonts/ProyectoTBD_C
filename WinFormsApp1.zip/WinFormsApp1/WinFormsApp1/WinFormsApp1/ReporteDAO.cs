﻿using System.Data;

public class ReporteDAO
{

    private ConexionDB conexion;

    public ReporteDAO()
    {
        conexion = new ConexionDB();
    }

    public DataTable ObtenerReporteVentasMes(int mes, int año)
    {
        string query = @"
            SELECT * FROM reporte_ventas_mes
            WHERE MONTH(FechaCompleta) = @mes AND YEAR(FechaCompleta) = @año";

        var parametros = new Dictionary<string, object>
        {
            { "@mes", mes },
            { "@año", año }
        };

        return conexion.EjecutarConsulta1(query, parametros);
    }

    public DataTable ObtenerReporteVentasPorEmpleado(int mes, int año)
    {
        string query = @"
            SELECT * FROM reporte_ventas_empleado
            WHERE Periodo = @periodo";

        string periodo = año.ToString() + "-" + mes.ToString("D2");

        var parametros = new Dictionary<string, object>
        {
            { "@periodo", periodo }
        };

        return conexion.EjecutarConsulta1(query, parametros);
    }

    public DataTable ObtenerReporteTrimestral(int año)
    {
        string query = @"
            SELECT * FROM reporte_ventas_trimestrales
            WHERE Año = @año";

        var parametros = new Dictionary<string, object>
        {
            { "@año", año }
        };

        return conexion.EjecutarConsulta1(query, parametros);
    }
}



