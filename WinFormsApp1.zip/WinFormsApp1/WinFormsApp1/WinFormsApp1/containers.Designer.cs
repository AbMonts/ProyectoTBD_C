﻿namespace WinFormsApp1
{
    partial class containers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabClientes = new TabControl();
            tabclien = new TabPage();
            btnCE = new Button();
            LBLC = new Label();
            TXTBC = new TextBox();
            dataGridViewC = new DataGridView();
            txtAC = new TextBox();
            txtDC = new TextBox();
            txtNC = new TextBox();
            lblDireccion = new Label();
            btnGCl = new Button();
            btnCCl = new Button();
            lblApellido = new Label();
            lblNombre = new Label();
            panel1 = new Panel();
            lblCliente = new Label();
            lblEditarOagregar = new Label();
            tabEmpleados = new TabPage();
            btnEE = new Button();
            lblEB = new Label();
            TXTBE = new TextBox();
            dataGridViewE = new DataGridView();
            txtSE = new TextBox();
            txtFE = new TextBox();
            txtCE = new TextBox();
            lblFoto = new Label();
            lblSalario = new Label();
            lblPass = new Label();
            txtAE = new TextBox();
            txtUE = new TextBox();
            txtNE = new TextBox();
            lblUser = new Label();
            btnGEm = new Button();
            btbCEm = new Button();
            lblApell = new Label();
            label3 = new Label();
            panel3 = new Panel();
            label4 = new Label();
            label5 = new Label();
            tabprodu = new TabPage();
            btnPE = new Button();
            dataGridViewP = new DataGridView();
            label6 = new Label();
            txtPB = new TextBox();
            lblMarca = new Label();
            txtPM = new TextBox();
            txtPCa = new TextBox();
            txtPF = new TextBox();
            txtPD = new TextBox();
            lblImagen = new Label();
            lblCant = new Label();
            lblDescip = new Label();
            txtPC = new TextBox();
            txtPP = new TextBox();
            txtPN = new TextBox();
            lblPrecio = new Label();
            btnGP = new Button();
            btnCP = new Button();
            lblCodigo = new Label();
            label1 = new Label();
            panel2 = new Panel();
            lblEmpleado = new Label();
            label2 = new Label();
            tabReport = new TabPage();
            dataGridViewR = new DataGridView();
            panel4 = new Panel();
            label7 = new Label();
            label8 = new Label();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel5 = new Panel();
            lblRep = new Label();
            label9 = new Label();
            tabClientes.SuspendLayout();
            tabclien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewC).BeginInit();
            panel1.SuspendLayout();
            tabEmpleados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewE).BeginInit();
            panel3.SuspendLayout();
            tabprodu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewP).BeginInit();
            panel2.SuspendLayout();
            tabReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewR).BeginInit();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            SuspendLayout();
            // 
            // tabClientes
            // 
            tabClientes.Controls.Add(tabclien);
            tabClientes.Controls.Add(tabEmpleados);
            tabClientes.Controls.Add(tabprodu);
            tabClientes.Controls.Add(tabReport);
            tabClientes.Location = new Point(12, 12);
            tabClientes.Name = "tabClientes";
            tabClientes.SelectedIndex = 0;
            tabClientes.Size = new Size(1216, 584);
            tabClientes.TabIndex = 0;
            tabClientes.SelectedIndexChanged += tabClientes_SelectedIndexChanged;
            // 
            // tabclien
            // 
            tabclien.Controls.Add(btnCE);
            tabclien.Controls.Add(LBLC);
            tabclien.Controls.Add(TXTBC);
            tabclien.Controls.Add(dataGridViewC);
            tabclien.Controls.Add(txtAC);
            tabclien.Controls.Add(txtDC);
            tabclien.Controls.Add(txtNC);
            tabclien.Controls.Add(lblDireccion);
            tabclien.Controls.Add(btnGCl);
            tabclien.Controls.Add(btnCCl);
            tabclien.Controls.Add(lblApellido);
            tabclien.Controls.Add(lblNombre);
            tabclien.Controls.Add(panel1);
            tabclien.Location = new Point(4, 29);
            tabclien.Name = "tabclien";
            tabclien.Padding = new Padding(3);
            tabclien.Size = new Size(1208, 551);
            tabclien.TabIndex = 0;
            tabclien.Text = "Clientes";
            tabclien.UseVisualStyleBackColor = true;
            tabclien.Click += tabclien_Click;
            // 
            // btnCE
            // 
            btnCE.Location = new Point(394, 354);
            btnCE.Name = "btnCE";
            btnCE.Size = new Size(110, 76);
            btnCE.TabIndex = 54;
            btnCE.Text = "Eliminar";
            btnCE.UseVisualStyleBackColor = true;
            btnCE.Click += btnCE_Click;
            // 
            // LBLC
            // 
            LBLC.AutoSize = true;
            LBLC.Location = new Point(575, 13);
            LBLC.Name = "LBLC";
            LBLC.Size = new Size(123, 20);
            LBLC.TabIndex = 52;
            LBLC.Text = "BUSCAR CLIENTE";
            // 
            // TXTBC
            // 
            TXTBC.Location = new Point(575, 45);
            TXTBC.Margin = new Padding(3, 4, 3, 4);
            TXTBC.Name = "TXTBC";
            TXTBC.Size = new Size(533, 27);
            TXTBC.TabIndex = 51;
            TXTBC.TextChanged += TXTBC_TextChanged;
            // 
            // dataGridViewC
            // 
            dataGridViewC.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewC.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewC.Location = new Point(575, 92);
            dataGridViewC.Name = "dataGridViewC";
            dataGridViewC.RowHeadersWidth = 51;
            dataGridViewC.Size = new Size(627, 453);
            dataGridViewC.TabIndex = 50;
            dataGridViewC.CellClick += dataGridViewC_CellClick;
            dataGridViewC.CellDoubleClick += dataGridViewC_CellDoubleClick;
            dataGridViewC.Click += dataGridViewC_Click;
            dataGridViewC.Enter += dataGridViewC_Enter;
            // 
            // txtAC
            // 
            txtAC.Location = new Point(99, 208);
            txtAC.Name = "txtAC";
            txtAC.Size = new Size(446, 27);
            txtAC.TabIndex = 49;
            // 
            // txtDC
            // 
            txtDC.Location = new Point(99, 271);
            txtDC.Name = "txtDC";
            txtDC.Size = new Size(405, 27);
            txtDC.TabIndex = 48;
            // 
            // txtNC
            // 
            txtNC.Location = new Point(99, 150);
            txtNC.Name = "txtNC";
            txtNC.Size = new Size(446, 27);
            txtNC.TabIndex = 47;
            // 
            // lblDireccion
            // 
            lblDireccion.AutoSize = true;
            lblDireccion.Location = new Point(104, 248);
            lblDireccion.Name = "lblDireccion";
            lblDireccion.Size = new Size(72, 20);
            lblDireccion.TabIndex = 46;
            lblDireccion.Text = "Direcion: ";
            // 
            // btnGCl
            // 
            btnGCl.Location = new Point(214, 354);
            btnGCl.Name = "btnGCl";
            btnGCl.Size = new Size(139, 76);
            btnGCl.TabIndex = 45;
            btnGCl.Text = "Guardar";
            btnGCl.UseVisualStyleBackColor = true;
            btnGCl.Click += btnGCl_Click;
            // 
            // btnCCl
            // 
            btnCCl.Location = new Point(37, 354);
            btnCCl.Name = "btnCCl";
            btnCCl.Size = new Size(139, 76);
            btnCCl.TabIndex = 44;
            btnCCl.Text = "Cancelar";
            btnCCl.UseVisualStyleBackColor = true;
            btnCCl.Click += btnCCl_Click;
            // 
            // lblApellido
            // 
            lblApellido.AutoSize = true;
            lblApellido.Location = new Point(97, 185);
            lblApellido.Name = "lblApellido";
            lblApellido.Size = new Size(73, 20);
            lblApellido.TabIndex = 43;
            lblApellido.Text = "Apellido: ";
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(99, 127);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(71, 20);
            lblNombre.TabIndex = 42;
            lblNombre.Text = "Nombre: ";
            // 
            // panel1
            // 
            panel1.Controls.Add(lblCliente);
            panel1.Controls.Add(lblEditarOagregar);
            panel1.Location = new Point(21, 17);
            panel1.Name = "panel1";
            panel1.Size = new Size(524, 93);
            panel1.TabIndex = 41;
            // 
            // lblCliente
            // 
            lblCliente.AutoSize = true;
            lblCliente.Font = new Font("Verdana", 16.2F, FontStyle.Bold);
            lblCliente.Location = new Point(264, 46);
            lblCliente.Name = "lblCliente";
            lblCliente.Size = new Size(126, 34);
            lblCliente.TabIndex = 1;
            lblCliente.Text = "Cliente";
            // 
            // lblEditarOagregar
            // 
            lblEditarOagregar.AutoSize = true;
            lblEditarOagregar.Font = new Font("Verdana", 16.2F, FontStyle.Bold);
            lblEditarOagregar.Location = new Point(62, 20);
            lblEditarOagregar.Name = "lblEditarOagregar";
            lblEditarOagregar.Size = new Size(125, 34);
            lblEditarOagregar.TabIndex = 0;
            lblEditarOagregar.Text = "Nuevo ";
            // 
            // tabEmpleados
            // 
            tabEmpleados.Controls.Add(btnEE);
            tabEmpleados.Controls.Add(lblEB);
            tabEmpleados.Controls.Add(TXTBE);
            tabEmpleados.Controls.Add(dataGridViewE);
            tabEmpleados.Controls.Add(txtSE);
            tabEmpleados.Controls.Add(txtFE);
            tabEmpleados.Controls.Add(txtCE);
            tabEmpleados.Controls.Add(lblFoto);
            tabEmpleados.Controls.Add(lblSalario);
            tabEmpleados.Controls.Add(lblPass);
            tabEmpleados.Controls.Add(txtAE);
            tabEmpleados.Controls.Add(txtUE);
            tabEmpleados.Controls.Add(txtNE);
            tabEmpleados.Controls.Add(lblUser);
            tabEmpleados.Controls.Add(btnGEm);
            tabEmpleados.Controls.Add(btbCEm);
            tabEmpleados.Controls.Add(lblApell);
            tabEmpleados.Controls.Add(label3);
            tabEmpleados.Controls.Add(panel3);
            tabEmpleados.Location = new Point(4, 29);
            tabEmpleados.Name = "tabEmpleados";
            tabEmpleados.Padding = new Padding(3);
            tabEmpleados.Size = new Size(1208, 551);
            tabEmpleados.TabIndex = 1;
            tabEmpleados.Text = "Empleados";
            tabEmpleados.UseVisualStyleBackColor = true;
            // 
            // btnEE
            // 
            btnEE.Location = new Point(385, 457);
            btnEE.Name = "btnEE";
            btnEE.Size = new Size(110, 76);
            btnEE.TabIndex = 54;
            btnEE.Text = "Eliminar";
            btnEE.UseVisualStyleBackColor = true;
            btnEE.Click += btnEE_Click;
            // 
            // lblEB
            // 
            lblEB.AutoSize = true;
            lblEB.Location = new Point(555, 11);
            lblEB.Name = "lblEB";
            lblEB.Size = new Size(144, 20);
            lblEB.TabIndex = 32;
            lblEB.Text = "BUSCAR EMPLEADO";
            // 
            // TXTBE
            // 
            TXTBE.Location = new Point(555, 35);
            TXTBE.Margin = new Padding(3, 4, 3, 4);
            TXTBE.Name = "TXTBE";
            TXTBE.Size = new Size(533, 27);
            TXTBE.TabIndex = 31;
            TXTBE.TextChanged += TXTBE_TextChanged;
            // 
            // dataGridViewE
            // 
            dataGridViewE.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewE.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewE.Location = new Point(540, 94);
            dataGridViewE.Name = "dataGridViewE";
            dataGridViewE.RowHeadersWidth = 51;
            dataGridViewE.Size = new Size(662, 451);
            dataGridViewE.TabIndex = 30;
            dataGridViewE.CellClick += dataGridViewE_CellClick;
            dataGridViewE.CellContentClick += dataGridViewE_CellContentClick;
            dataGridViewE.CellContentDoubleClick += dataGridViewE_CellContentDoubleClick;
            dataGridViewE.CellDoubleClick += dataGridViewE_CellDoubleClick;
            dataGridViewE.Click += dataGridViewE_Click;
            // 
            // txtSE
            // 
            txtSE.Location = new Point(88, 334);
            txtSE.Name = "txtSE";
            txtSE.Size = new Size(201, 27);
            txtSE.TabIndex = 29;
            // 
            // txtFE
            // 
            txtFE.Location = new Point(88, 397);
            txtFE.Name = "txtFE";
            txtFE.Size = new Size(407, 27);
            txtFE.TabIndex = 28;
            // 
            // txtCE
            // 
            txtCE.Location = new Point(297, 261);
            txtCE.Name = "txtCE";
            txtCE.Size = new Size(227, 27);
            txtCE.TabIndex = 27;
            // 
            // lblFoto
            // 
            lblFoto.AutoSize = true;
            lblFoto.Location = new Point(86, 374);
            lblFoto.Name = "lblFoto";
            lblFoto.Size = new Size(74, 20);
            lblFoto.TabIndex = 26;
            lblFoto.Text = "Link foto: ";
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Location = new Point(86, 311);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(62, 20);
            lblSalario.TabIndex = 25;
            lblSalario.Text = "Salario: ";
            // 
            // lblPass
            // 
            lblPass.AutoSize = true;
            lblPass.Location = new Point(297, 238);
            lblPass.Name = "lblPass";
            lblPass.Size = new Size(90, 20);
            lblPass.TabIndex = 24;
            lblPass.Text = "Contraseña: ";
            // 
            // txtAE
            // 
            txtAE.Location = new Point(88, 198);
            txtAE.Name = "txtAE";
            txtAE.Size = new Size(446, 27);
            txtAE.TabIndex = 23;
            // 
            // txtUE
            // 
            txtUE.Location = new Point(88, 261);
            txtUE.Name = "txtUE";
            txtUE.Size = new Size(153, 27);
            txtUE.TabIndex = 22;
            // 
            // txtNE
            // 
            txtNE.Location = new Point(88, 140);
            txtNE.Name = "txtNE";
            txtNE.Size = new Size(446, 27);
            txtNE.TabIndex = 21;
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.Location = new Point(93, 238);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(66, 20);
            lblUser.TabIndex = 20;
            lblUser.Text = "Usuario: ";
            // 
            // btnGEm
            // 
            btnGEm.Location = new Point(218, 457);
            btnGEm.Name = "btnGEm";
            btnGEm.Size = new Size(139, 76);
            btnGEm.TabIndex = 19;
            btnGEm.Text = "Guardar";
            btnGEm.UseVisualStyleBackColor = true;
            btnGEm.Click += btnGEm_Click;
            // 
            // btbCEm
            // 
            btbCEm.Location = new Point(40, 457);
            btbCEm.Name = "btbCEm";
            btbCEm.Size = new Size(139, 76);
            btbCEm.TabIndex = 18;
            btbCEm.Text = "Cancelar";
            btbCEm.UseVisualStyleBackColor = true;
            btbCEm.Click += btbCEm_Click;
            // 
            // lblApell
            // 
            lblApell.AutoSize = true;
            lblApell.Location = new Point(86, 175);
            lblApell.Name = "lblApell";
            lblApell.Size = new Size(73, 20);
            lblApell.TabIndex = 17;
            lblApell.Text = "Apellido: ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(88, 117);
            label3.Name = "label3";
            label3.Size = new Size(71, 20);
            label3.TabIndex = 16;
            label3.Text = "Nombre: ";
            // 
            // panel3
            // 
            panel3.Controls.Add(label4);
            panel3.Controls.Add(label5);
            panel3.Location = new Point(10, 7);
            panel3.Name = "panel3";
            panel3.Size = new Size(524, 93);
            panel3.TabIndex = 15;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 16.2F, FontStyle.Bold);
            label4.Location = new Point(264, 46);
            label4.Name = "label4";
            label4.Size = new Size(171, 34);
            label4.TabIndex = 1;
            label4.Text = "Empleado";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 16.2F, FontStyle.Bold);
            label5.Location = new Point(62, 20);
            label5.Name = "label5";
            label5.Size = new Size(125, 34);
            label5.TabIndex = 0;
            label5.Text = "Nuevo ";
            label5.DoubleClick += label5_DoubleClick;
            // 
            // tabprodu
            // 
            tabprodu.Controls.Add(btnPE);
            tabprodu.Controls.Add(dataGridViewP);
            tabprodu.Controls.Add(label6);
            tabprodu.Controls.Add(txtPB);
            tabprodu.Controls.Add(lblMarca);
            tabprodu.Controls.Add(txtPM);
            tabprodu.Controls.Add(txtPCa);
            tabprodu.Controls.Add(txtPF);
            tabprodu.Controls.Add(txtPD);
            tabprodu.Controls.Add(lblImagen);
            tabprodu.Controls.Add(lblCant);
            tabprodu.Controls.Add(lblDescip);
            tabprodu.Controls.Add(txtPC);
            tabprodu.Controls.Add(txtPP);
            tabprodu.Controls.Add(txtPN);
            tabprodu.Controls.Add(lblPrecio);
            tabprodu.Controls.Add(btnGP);
            tabprodu.Controls.Add(btnCP);
            tabprodu.Controls.Add(lblCodigo);
            tabprodu.Controls.Add(label1);
            tabprodu.Controls.Add(panel2);
            tabprodu.Location = new Point(4, 29);
            tabprodu.Name = "tabprodu";
            tabprodu.Padding = new Padding(3);
            tabprodu.Size = new Size(1208, 551);
            tabprodu.TabIndex = 2;
            tabprodu.Text = "Productos";
            tabprodu.UseVisualStyleBackColor = true;
            // 
            // btnPE
            // 
            btnPE.Location = new Point(385, 458);
            btnPE.Name = "btnPE";
            btnPE.Size = new Size(122, 76);
            btnPE.TabIndex = 67;
            btnPE.Text = "Eliminar";
            btnPE.UseVisualStyleBackColor = true;
            btnPE.Click += btnPE_Click;
            // 
            // dataGridViewP
            // 
            dataGridViewP.BackgroundColor = SystemColors.ControlLight;
            dataGridViewP.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewP.Location = new Point(569, 80);
            dataGridViewP.Name = "dataGridViewP";
            dataGridViewP.RowHeadersWidth = 51;
            dataGridViewP.Size = new Size(623, 454);
            dataGridViewP.TabIndex = 66;
            dataGridViewP.CellClick += dataGridViewP_CellClick;
            dataGridViewP.CellDoubleClick += dataGridViewP_CellDoubleClick;
            dataGridViewP.Click += dataGridViewP_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(569, 12);
            label6.Name = "label6";
            label6.Size = new Size(144, 20);
            label6.TabIndex = 1;
            label6.Text = "BUSCAR PRODUCTO";
            // 
            // txtPB
            // 
            txtPB.Location = new Point(569, 36);
            txtPB.Margin = new Padding(3, 4, 3, 4);
            txtPB.Name = "txtPB";
            txtPB.Size = new Size(533, 27);
            txtPB.TabIndex = 0;
            txtPB.TextChanged += textBox17_TextChanged;
            // 
            // lblMarca
            // 
            lblMarca.AutoSize = true;
            lblMarca.Location = new Point(321, 312);
            lblMarca.Name = "lblMarca";
            lblMarca.Size = new Size(53, 20);
            lblMarca.TabIndex = 65;
            lblMarca.Text = "Marca:";
            // 
            // txtPM
            // 
            txtPM.Location = new Point(321, 335);
            txtPM.Name = "txtPM";
            txtPM.Size = new Size(153, 27);
            txtPM.TabIndex = 64;
            // 
            // txtPCa
            // 
            txtPCa.Location = new Point(84, 335);
            txtPCa.Name = "txtPCa";
            txtPCa.Size = new Size(201, 27);
            txtPCa.TabIndex = 63;
            // 
            // txtPF
            // 
            txtPF.Location = new Point(84, 398);
            txtPF.Name = "txtPF";
            txtPF.Size = new Size(407, 27);
            txtPF.TabIndex = 62;
            // 
            // txtPD
            // 
            txtPD.Location = new Point(293, 262);
            txtPD.Name = "txtPD";
            txtPD.Size = new Size(227, 27);
            txtPD.TabIndex = 61;
            // 
            // lblImagen
            // 
            lblImagen.AutoSize = true;
            lblImagen.Location = new Point(82, 375);
            lblImagen.Name = "lblImagen";
            lblImagen.Size = new Size(96, 20);
            lblImagen.TabIndex = 60;
            lblImagen.Text = "Link imagen: ";
            // 
            // lblCant
            // 
            lblCant.AutoSize = true;
            lblCant.Location = new Point(82, 312);
            lblCant.Name = "lblCant";
            lblCant.Size = new Size(76, 20);
            lblCant.TabIndex = 59;
            lblCant.Text = "Cantidad: ";
            // 
            // lblDescip
            // 
            lblDescip.AutoSize = true;
            lblDescip.Location = new Point(293, 239);
            lblDescip.Name = "lblDescip";
            lblDescip.Size = new Size(90, 20);
            lblDescip.TabIndex = 58;
            lblDescip.Text = "Descripcion:";
            // 
            // txtPC
            // 
            txtPC.Location = new Point(84, 199);
            txtPC.Name = "txtPC";
            txtPC.Size = new Size(446, 27);
            txtPC.TabIndex = 57;
            // 
            // txtPP
            // 
            txtPP.Location = new Point(84, 262);
            txtPP.Name = "txtPP";
            txtPP.Size = new Size(153, 27);
            txtPP.TabIndex = 56;
            // 
            // txtPN
            // 
            txtPN.Location = new Point(84, 141);
            txtPN.Name = "txtPN";
            txtPN.Size = new Size(446, 27);
            txtPN.TabIndex = 55;
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(89, 239);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(57, 20);
            lblPrecio.TabIndex = 54;
            lblPrecio.Text = "Precio: ";
            // 
            // btnGP
            // 
            btnGP.Location = new Point(204, 458);
            btnGP.Name = "btnGP";
            btnGP.Size = new Size(139, 76);
            btnGP.TabIndex = 53;
            btnGP.Text = "Guardar";
            btnGP.UseVisualStyleBackColor = true;
            btnGP.Click += btnGP_Click;
            // 
            // btnCP
            // 
            btnCP.Location = new Point(39, 458);
            btnCP.Name = "btnCP";
            btnCP.Size = new Size(139, 76);
            btnCP.TabIndex = 52;
            btnCP.Text = "Cancelar";
            btnCP.UseVisualStyleBackColor = true;
            btnCP.Click += btnCP_Click;
            // 
            // lblCodigo
            // 
            lblCodigo.AutoSize = true;
            lblCodigo.Location = new Point(82, 176);
            lblCodigo.Name = "lblCodigo";
            lblCodigo.Size = new Size(65, 20);
            lblCodigo.TabIndex = 51;
            lblCodigo.Text = "Codigo: ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(84, 118);
            label1.Name = "label1";
            label1.Size = new Size(71, 20);
            label1.TabIndex = 50;
            label1.Text = "Nombre: ";
            // 
            // panel2
            // 
            panel2.Controls.Add(lblEmpleado);
            panel2.Controls.Add(label2);
            panel2.Location = new Point(6, 8);
            panel2.Name = "panel2";
            panel2.Size = new Size(524, 93);
            panel2.TabIndex = 49;
            // 
            // lblEmpleado
            // 
            lblEmpleado.AutoSize = true;
            lblEmpleado.Font = new Font("Verdana", 16.2F, FontStyle.Bold);
            lblEmpleado.Location = new Point(264, 46);
            lblEmpleado.Name = "lblEmpleado";
            lblEmpleado.Size = new Size(157, 34);
            lblEmpleado.TabIndex = 1;
            lblEmpleado.Text = "Producto";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 16.2F, FontStyle.Bold);
            label2.Location = new Point(62, 20);
            label2.Name = "label2";
            label2.Size = new Size(125, 34);
            label2.TabIndex = 0;
            label2.Text = "Nuevo ";
            // 
            // tabReport
            // 
            tabReport.Controls.Add(dataGridViewR);
            tabReport.Controls.Add(panel4);
            tabReport.Controls.Add(panel5);
            tabReport.Location = new Point(4, 29);
            tabReport.Name = "tabReport";
            tabReport.Padding = new Padding(3);
            tabReport.Size = new Size(1208, 551);
            tabReport.TabIndex = 3;
            tabReport.Text = "Reportes";
            tabReport.UseVisualStyleBackColor = true;
            // 
            // dataGridViewR
            // 
            dataGridViewR.BackgroundColor = SystemColors.ButtonHighlight;
            dataGridViewR.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewR.GridColor = Color.AntiqueWhite;
            dataGridViewR.Location = new Point(380, 119);
            dataGridViewR.Name = "dataGridViewR";
            dataGridViewR.RowHeadersWidth = 51;
            dataGridViewR.Size = new Size(803, 426);
            dataGridViewR.TabIndex = 4;
            // 
            // panel4
            // 
            panel4.Controls.Add(label7);
            panel4.Controls.Add(label8);
            panel4.Controls.Add(comboBox2);
            panel4.Controls.Add(comboBox1);
            panel4.Controls.Add(button3);
            panel4.Controls.Add(button2);
            panel4.Controls.Add(button1);
            panel4.Location = new Point(23, 119);
            panel4.Name = "panel4";
            panel4.Size = new Size(336, 426);
            panel4.TabIndex = 3;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(166, 0);
            label7.Name = "label7";
            label7.Size = new Size(71, 25);
            label7.TabIndex = 6;
            label7.Text = "Año: ";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(34, 0);
            label8.Name = "label8";
            label8.Size = new Size(71, 25);
            label8.TabIndex = 5;
            label8.Text = "Mes: ";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "2024", "2023", "2022", "2021", "2019", "2018", "2017" });
            comboBox2.Location = new Point(166, 38);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(93, 28);
            comboBox2.TabIndex = 4;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" });
            comboBox1.Location = new Point(34, 38);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(92, 28);
            comboBox1.TabIndex = 3;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            button3.Location = new Point(34, 328);
            button3.Name = "button3";
            button3.Size = new Size(190, 98);
            button3.TabIndex = 2;
            button3.Text = "Trimestral";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            button2.Location = new Point(34, 205);
            button2.Name = "button2";
            button2.Size = new Size(190, 98);
            button2.TabIndex = 1;
            button2.Text = "Empleado";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic);
            button1.Location = new Point(34, 87);
            button1.Name = "button1";
            button1.Size = new Size(190, 98);
            button1.TabIndex = 0;
            button1.Text = "Mensual";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // panel5
            // 
            panel5.Controls.Add(lblRep);
            panel5.Controls.Add(label9);
            panel5.Location = new Point(23, 18);
            panel5.Name = "panel5";
            panel5.Size = new Size(1160, 80);
            panel5.TabIndex = 2;
            // 
            // lblRep
            // 
            lblRep.AutoSize = true;
            lblRep.Font = new Font("Verdana", 16.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            lblRep.Location = new Point(506, 18);
            lblRep.Name = "lblRep";
            lblRep.Size = new Size(153, 34);
            lblRep.TabIndex = 1;
            lblRep.Text = "operacion";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Tahoma", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(131, 15);
            label9.Name = "label9";
            label9.Size = new Size(244, 36);
            label9.TabIndex = 0;
            label9.Text = "Reporte ventas";
            // 
            // containers
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1255, 601);
            Controls.Add(tabClientes);
            Name = "containers";
            Text = "containers";
            Load += containers_Load;
            tabClientes.ResumeLayout(false);
            tabclien.ResumeLayout(false);
            tabclien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewC).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            tabEmpleados.ResumeLayout(false);
            tabEmpleados.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewE).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            tabprodu.ResumeLayout(false);
            tabprodu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewP).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            tabReport.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridViewR).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabClientes;
        private TabPage tabclien;
        private TabPage tabEmpleados;
        private TabPage tabprodu;
        private TextBox txtAC;
        private TextBox txtDC;
        private TextBox txtNC;
        private Label lblDireccion;
        private Button btnGCl;
        private Button btnCCl;
        private Label lblApellido;
        private Label lblNombre;
        private Panel panel1;
        private Label lblCliente;
        private Label lblEditarOagregar;
        private Label lblMarca;
        private TextBox txtPM;
        private TextBox txtPCa;
        private TextBox txtPF;
        private TextBox txtPD;
        private Label lblImagen;
        private Label lblCant;
        private Label lblDescip;
        private TextBox txtPC;
        private TextBox txtPP;
        private TextBox txtPN;
        private Label lblPrecio;
        private Button btnGP;
        private Button btnCP;
        private Label lblCodigo;
        private Label label1;
        private Panel panel2;
        private Label lblEmpleado;
        private Label label2;
        private TextBox txtSE;
        private TextBox txtFE;
        private TextBox txtCE;
        private Label lblFoto;
        private Label lblSalario;
        private Label lblPass;
        private TextBox txtAE;
        private TextBox txtUE;
        private TextBox txtNE;
        private Label lblUser;
        private Button btnGEm;
        private Button btbCEm;
        private Label lblApell;
        private Label label3;
        private Panel panel3;
        private Label label4;
        private Label label5;
        private DataGridView dataGridViewE;
        private DataGridView dataGridViewC;
        private TabPage tabReport;
        private Label label6;
        private TextBox txtPB;
        private DataGridView dataGridViewP;
        private Panel panel4;
        private Label label7;
        private Label label8;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private Button button3;
        private Button button2;
        private Button button1;
        private Panel panel5;
        private DataGridView dataGridViewR;
        private Label lblRep;
        private Label label9;
        private Label lblEB;
        private TextBox TXTBE;
        private Label LBLC;
        private TextBox TXTBC;
        private Button btnEE;
        private Button btnPE;
        private Button btnCE;
    }
}