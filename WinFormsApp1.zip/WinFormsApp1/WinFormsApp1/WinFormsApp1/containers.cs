﻿using System;
using System.Data;
using System;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using System.Text;

namespace WinFormsApp1
{

    public partial class containers : Form
    {
        int idE = 0;
        int idP = 0;
        int idC = 0;

        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        ClientesDAO clientesDAO = new ClientesDAO();
        ProductoDAO productoDAO = new ProductoDAO();
        public containers()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 1;
            comboBox2.SelectedIndex = 1;





        }

        private void containers_Load(object sender, EventArgs e)
        {
            btnGCl.Enabled = false;
            btnGEm.Enabled = false;
            btnGP.Enabled = false;
            btnCE.Enabled = false;
            btnEE.Enabled = false;
            btnPE.Enabled = false;
            LlenarDataGridViewClientes(dataGridViewC);
            LlenarDataGridViewProductos(dataGridViewP);
            LlenarDataGridViewEmpleados(dataGridViewE);

        }

        public void LlenarDataGridViewVentasMes(DataGridView dataGridView, int mes, int año)
        {
            try
            {
                LimpiarDataGridView(dataGridView);

                ReporteDAO reporteDAO = new ReporteDAO();
                DataTable datosMes = reporteDAO.ObtenerReporteVentasMes(mes, año);

                if (datosMes.Rows.Count > 0)
                {
                    dataGridView.DataSource = datosMes;
                }
                else
                {
                    MessageBox.Show("No se encontraron datos para el reporte mensual.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al llenar el reporte mensual: {ex.Message}");
            }
        }



        public void LlenarDataGridViewVentasPorEmpleado(DataGridView dataGridView, int mes, int año)
        {
            try
            {
                LimpiarDataGridView(dataGridView);

                ReporteDAO reporteDAO = new ReporteDAO();
                DataTable datosEmpleado = reporteDAO.ObtenerReporteVentasPorEmpleado(mes, año);

                if (datosEmpleado.Rows.Count > 0)
                {
                    dataGridView.DataSource = datosEmpleado;
                }
                else
                {
                    MessageBox.Show("No se encontraron datos para el reporte por empleado.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al llenar el reporte de empleado: {ex.Message}");
            }
        }



        public void LlenarDataGridViewReporteTrimestral(DataGridView dataGridView, int año)
        {
            try
            {
                LimpiarDataGridView(dataGridView);

                ReporteDAO reporteDAO = new ReporteDAO();
                DataTable datosTrimestral = reporteDAO.ObtenerReporteTrimestral(año);

                if (datosTrimestral.Rows.Count > 0)
                {
                    dataGridView.DataSource = datosTrimestral;
                }
                else
                {
                    MessageBox.Show("No se encontraron datos para el reporte trimestral.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al llenar el reporte trimestral: {ex.Message}");
            }
        }

        public void LlenarDataGridViewEmpleados(DataGridView dataGridView)
        {
            try
            {
                LimpiarDataGridView(dataGridView);

                EmpleadoDAO empleadoDAO = new EmpleadoDAO();
                DataTable datosEmpleados = empleadoDAO.ObtenerEmpleados();

                if (datosEmpleados.Rows.Count > 0)
                {
                    dataGridView.DataSource = datosEmpleados;
                }
                else
                {
                    MessageBox.Show("No se encontraron datos de empleados.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al llenar el DataGridView con empleados: {ex.Message}");
            }
        }


        public void LlenarDataGridViewProductos(DataGridView dataGridView)
        {
            try
            {
                LimpiarDataGridView(dataGridView);

                ProductoDAO productoDAO = new ProductoDAO();
                DataTable datosProductos = productoDAO.ObtenerProductos();

                if (datosProductos.Rows.Count > 0)
                {
                    dataGridView.DataSource = datosProductos;
                }
                else
                {
                    MessageBox.Show("No se encontraron datos de productos.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al llenar el DataGridView con productos: {ex.Message}");
            }
        }

        //que cargen el gridview con la info, se limpie antes de cargar uno o otro
        private void button1_Click(object sender, EventArgs e)
        {
            lblRep.Text = "Mensual";
            int mes = Convert.ToInt32(comboBox1.SelectedItem);
            int año = Convert.ToInt32(comboBox2.SelectedItem);

            LlenarDataGridViewVentasMes(dataGridViewR, mes, año);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lblRep.Text = "Empleado";
            int mes = Convert.ToInt32(comboBox1.SelectedItem);
            int año = Convert.ToInt32(comboBox2.SelectedItem);

            LlenarDataGridViewVentasPorEmpleado(dataGridViewR, mes, año);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lblRep.Text = "Trimestral";
            int año = Convert.ToInt32(comboBox2.SelectedItem);

            LlenarDataGridViewReporteTrimestral(dataGridViewR, año);
        }



        private void tabclien_Click(object sender, EventArgs e)
        {

        }

        private void LimpiarDataGridView(DataGridView dataGridView)
        {
            dataGridView.DataSource = null;
            dataGridView.Rows.Clear();
            dataGridView.Columns.Clear();

        }

        public void LlenarDataGridViewClientes(DataGridView dataGridView)
        {
            try
            {
                LimpiarDataGridView(dataGridView);

                ClientesDAO clienteDAO = new ClientesDAO();
                DataTable datosClientes = clienteDAO.ObtenerClientes();

                if (datosClientes.Rows.Count > 0)
                {
                    dataGridView.DataSource = datosClientes;
                }
                else
                {
                    MessageBox.Show("No se encontraron datos de clientes.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al llenar el DataGridView con clientes: {ex.Message}");
            }
        }

        private void tabClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            LlenarDataGridViewClientes(dataGridViewC);
            LlenarDataGridViewProductos(dataGridViewP);
            LlenarDataGridViewEmpleados(dataGridViewE);
            int idE = 0;
        }
        private void btnCCl_Click(object sender, EventArgs e)
        {
            txtAC.Text = "";
            txtDC.Text = "";
            txtNC.Text = "";
            lblEditarOagregar.Text = "Agregar";
            btnGCl.Enabled = false;
            btnCE.Enabled = false;
        }

        //para empleados
        private void buscar(string texto)
        {
            DataTable resultados = empleadoDAO.BuscarEmpleados(texto);
            dataGridViewE.DataSource = resultados;

        }

        private void buscarClientes(string texto)
        {
            DataTable resultados = clientesDAO.BuscarClientes(texto);
            dataGridViewC.DataSource = resultados;
        }

        private void buscarProductos(string texto)
        {
            DataTable resultados = productoDAO.BuscarProductos(texto);
            dataGridViewP.DataSource = resultados;
        }



        private void textBox17_TextChanged(object sender, EventArgs e)
        {

            string textoBusqueda = txtPB.Text;
            buscarProductos(textoBusqueda);
        }

        //pa guardar cliente
        private void btnGCl_Click(object sender, EventArgs e)
        {
            try
            {
                string nombre = txtNC.Text;
                string apellido = txtAC.Text;
                string direccion = txtDC.Text;

                if (idC == 0)
                { // Insertar el nuevo cliente
                    clientesDAO.InsertarCliente(nombre, apellido, direccion); MessageBox.Show("Cliente guardado exitosamente");
                    btnGCl.Enabled = false;
                    btnCE.Enabled = false;
                }
                else
                {
                    clientesDAO.ActualizarCliente(idC, nombre, apellido, direccion);
                    MessageBox.Show("Cliente actualizado exitosamente");
                    btnGCl.Enabled = false;
                    btnCE.Enabled = false;
                }
                txtNC.Text = "";
                txtAC.Text = "";
                txtDC.Text = "";
                idC = 0;
                btnCE.Enabled = false;
                btnGCl.Enabled = false;
                LlenarDataGridViewClientes(dataGridViewC);

            }
            catch (Exception ex)
            {
                // Mostrar mensaje de error
                MessageBox.Show($"Error al guardar o actualizar el cliente: {ex.Message}");
            }
        }

        private void btbCEm_Click(object sender, EventArgs e)
        {
            txtAE.Text = "";
            txtNE.Text = "";
            txtCE.Text = "";
            txtFE.Text = "";
            txtSE.Text = "";
            txtUE.Text = "";
            txtCE.Enabled = true;
            label5.Text = "Agregar";
            btnGEm.Enabled = false;
            btnEE.Enabled = false;
        }

        //debe ser habilitado sal hacer doble click en una celda y se debe deshabilitar al dar en guardar
        private void btnGEm_Click(object sender, EventArgs e)
        {

            try
            {
                // Obtener los datos de los TextBox
                string nombre = txtNE.Text;
                string apellido = txtAE.Text;
                string usuario = txtUE.Text;
                string pass = txtCE.Text;
                float salario = float.Parse(txtSE.Text);
                string foto = txtFE.Text;

                // Encriptar la contraseña
                string passEncriptado = EncriptarPassword(pass);

                // Crear una instancia de EmpleadoDAO
                EmpleadoDAO empleadoDAO = new EmpleadoDAO();

                if (idE == 0)
                {
                    // Insertar el nuevo empleado con la contraseña encriptada
                    empleadoDAO.InsertarEmpleado(nombre, apellido, usuario, passEncriptado, salario, foto);
                    MessageBox.Show("Empleado guardado exitosamente");
                    btnGEm.Enabled = false;
                    btnEE.Enabled = false;
                }
                else
                {
                    // Actualizar el empleado existente
                    empleadoDAO.ActualizarEmpleado(idE, nombre, apellido, usuario, passEncriptado, salario, foto);
                    MessageBox.Show("Empleado actualizado exitosamente");
                    btnGEm.Enabled = false;
                    btnEE.Enabled = false;
                }

                // Limpiar los campos de entrada
                txtNE.Text = "";
                txtAE.Text = "";
                txtUE.Text = "";
                txtCE.Text = "";
                txtSE.Text = "";
                txtFE.Text = "";
                idE = 0;
                btnEE.Enabled = false;
                // Actualizar el DataGridView para reflejar los cambios
                LlenarDataGridViewEmpleados(dataGridViewE);
            }
            catch (Exception ex)
            {
                // Mostrar mensaje de error
                MessageBox.Show($"Error al guardar o actualizar el empleado: {ex.Message}");
            }
        }

        // Método para encriptar una contraseña usando SHA256
        private string EncriptarPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Convertir la contraseña en bytes
                byte[] bytes = Encoding.UTF8.GetBytes(password);

                // Generar el hash
                byte[] hashBytes = sha256.ComputeHash(bytes);

                // Convertir el hash a cadena hexadecimal
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    sb.Append(b.ToString("x2"));
                }

                return sb.ToString();
            }
        }


        private void dataGridViewE_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridViewE_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            label5.Text = "Editar";
            if (e.RowIndex >= 0)
            {
                btnGEm.Enabled = true;
                btnEE.Enabled = true;
                txtCE.Enabled = false;
                DataGridViewRow row = dataGridViewE.Rows[e.RowIndex]; // Asigna los valores de las celdas a los TextBox correspondientes
                txtNE.Text = row.Cells["nombre"].Value.ToString();
                txtAE.Text = row.Cells["apellido"].Value.ToString();
                txtUE.Text = row.Cells["usuario"].Value.ToString();
                txtSE.Text = row.Cells["salario"].Value.ToString();
                txtFE.Text = row.Cells["foto"].Value.ToString();
                txtCE.Text = row.Cells["pass"].Value.ToString();
                idE = Convert.ToInt32(row.Cells["idEmpleado"].Value);
            }



        }
        private void TXTBE_TextChanged(object sender, EventArgs e)
        {
            buscar(TXTBE.Text);
        }

        private void btnCP_Click(object sender, EventArgs e)
        {
            txtPC.Text = "";
            txtPCa.Text = "";
            txtPD.Text = "";
            txtPF.Text = "";
            txtPM.Text = "";
            txtPN.Text = "";
            txtPP.Text = "";
            label2.Text = "Agregar";
            btnGP.Enabled = false;
            btnGP.Enabled = false;
            btnPE.Enabled = false;

        }

        private void btnGP_Click(object sender, EventArgs e)
        {
            try
            {
                string nombre = txtPN.Text;
                string codigo = txtPC.Text;
                decimal precio = decimal.Parse(txtPP.Text);
                string descripcion = txtPD.Text;
                int cantidad = int.Parse(txtPCa.Text);
                int idMarca = int.Parse(txtPM.Text);
                string imagen = txtPF.Text; // Este campo puede ser vacío o nulo

                ProductoDAO productoDAO = new ProductoDAO();
                if (idP == 0)
                {
                    productoDAO.InsertarProducto(nombre, codigo, precio, descripcion, cantidad, idMarca, string.IsNullOrWhiteSpace(imagen) ? null : imagen);
                    MessageBox.Show("Producto guardado exitosamente");
                    idP = 0;
                    btnGP.Enabled = false;
                    btnPE.Enabled = false;
                }
                else
                {
                    productoDAO.ActualizarProducto(idP, nombre, codigo, precio, descripcion, cantidad, idMarca, string.IsNullOrWhiteSpace(imagen) ? null : imagen);
                    MessageBox.Show("Producto actualizado exitosamente");
                    idP = 0;
                    btnGP.Enabled = false;
                    btnPE.Enabled = false;
                }

                // Limpiar los campos de entrada
                txtPC.Text = "";
                txtPCa.Text = "";
                txtPD.Text = "";
                txtPF.Text = "";
                txtPM.Text = "";
                txtPN.Text = "";
                txtPP.Text = "";
                btnPE.Enabled = false;
                LlenarDataGridViewProductos(dataGridViewP);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al guardar o actualizar el producto: {ex.Message}");
            }
        }

        private void TXTBC_TextChanged(object sender, EventArgs e)
        {
            string textoBusqueda = TXTBC.Text;
            buscarClientes(textoBusqueda);
        }

        //para producto
        private void dataGridViewP_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            label2.Text = "Editar";
            if (e.RowIndex >= 0)
            {
                btnPE.Enabled = true;
                btnGP.Enabled = true;
                DataGridViewRow row = dataGridViewP.Rows[e.RowIndex];
                txtPC.Text = row.Cells["codigo"].Value.ToString();
                txtPCa.Text = row.Cells["cantidad"].Value.ToString();
                txtPD.Text = row.Cells["descripcion"].Value.ToString();
                txtPF.Text = row.Cells["imagen"].Value.ToString();
                txtPM.Text = row.Cells["idMarca"].Value.ToString();
                txtPN.Text = row.Cells["nombre"].Value.ToString();
                txtPP.Text = row.Cells["precio"].Value.ToString();
                idP = Convert.ToInt32(row.Cells["idProducto"].Value);
            }
        }

        //llenar campos de cliente
        private void dataGridViewC_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            lblEditarOagregar.Text = "Editar";
            if (e.RowIndex >= 0)
            {
                btnCE.Enabled = true;
                btnCE.Enabled = true;
                btnGCl.Enabled = true;
                DataGridViewRow row = dataGridViewC.Rows[e.RowIndex];
                txtNC.Text = row.Cells["nombre"].Value.ToString();
                txtAC.Text = row.Cells["apellido"].Value.ToString();
                txtDC.Text = row.Cells["direccion"].Value.ToString();
                idC = Convert.ToInt32(row.Cells["idCliente"].Value);
            }

        }

        private void dataGridViewE_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void btnCE_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewC.SelectedRows.Count > 0)
                {
                    int idCliente = Convert.ToInt32(dataGridViewC.SelectedRows[0].Cells["idCliente"].Value);


                    clientesDAO.EliminarCliente(idCliente);

                    MessageBox.Show("Cliente eliminado exitosamente");
                    LlenarDataGridViewClientes(dataGridViewC);
                    btnCE.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione un cliente para eliminar.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el cliente: {ex.Message}");
            }
        }


        private void btnEE_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewE.SelectedRows.Count > 0)
                {
                    int idEmpleado = Convert.ToInt32(dataGridViewE.SelectedRows[0].Cells["idEmpleado"].Value);

                    EmpleadoDAO empleadoDAO = new EmpleadoDAO();
                    empleadoDAO.EliminarEmpleado(idEmpleado);

                    MessageBox.Show("Empleado eliminado exitosamente");
                    LlenarDataGridViewEmpleados(dataGridViewE);
                    btnEE.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione un empleado para eliminar.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el empleado: {ex.Message}");
            }
        }


        private void btnPE_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewP.SelectedRows.Count > 0)
                {
                    int idProducto = Convert.ToInt32(dataGridViewP.SelectedRows[0].Cells["idProducto"].Value);

                    ProductoDAO productoDAO = new ProductoDAO();
                    productoDAO.EliminarProducto(idProducto);

                    MessageBox.Show("Producto eliminado exitosamente");
                    btnPE.Enabled = false;
                    LlenarDataGridViewProductos(dataGridViewP);
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione un producto para eliminar.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar el producto: {ex.Message}");
            }
        }

        private void label5_DoubleClick(object sender, EventArgs e)
        {

        }

        private void dataGridViewC_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                dataGridViewC.Rows[e.RowIndex].Selected = true;
            }
        }

        private void dataGridViewE_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dataGridViewE.Rows[e.RowIndex].Selected = true;
            }
        }

        private void dataGridViewP_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                dataGridViewP.Rows[e.RowIndex].Selected = true;
            }
        }

        private void dataGridViewC_Click(object sender, EventArgs e)
        {
            //btnGCl.Enabled = true;
        }

        private void dataGridViewC_Enter(object sender, EventArgs e)
        {
            btnGCl.Enabled = true;
        }

        private void dataGridViewE_Click(object sender, EventArgs e)
        {
            btnGEm.Enabled = true;
        }

        private void dataGridViewP_Click(object sender, EventArgs e)
        {
            btnGP.Enabled = true;
        }
    }

}